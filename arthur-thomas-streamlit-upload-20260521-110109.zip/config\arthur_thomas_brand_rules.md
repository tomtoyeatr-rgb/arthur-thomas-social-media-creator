# Arthur Thomas Properties Brand Rules

## Core Direction

Arthur Thomas Properties content must be professional, calm, clear, concise, and property-management focused.

The tone should be fair, reasonable, empathetic, and respectful toward residents, homeowners, clients, vendors, and local communities.

The brand should never sound salesy, aggressive, sarcastic, political, discriminatory, gimmicky, flashy, or combative.

## Company Overview

Brand name: Arthur Thomas Properties

Industry: Property Management / Real Estate Services

Geographic focus: New Hampshire and Southern Maine

Primary services:

- Residential property management
- Condo and HOA management
- Leasing and tenant placement
- Maintenance coordination
- Investor support
- Rental operations
- Resident communication
- Vendor coordination
- Property marketing

## Brand Positioning

Arthur Thomas Properties is a modern, thoughtful, systems-oriented property management company focused on professionalism, communication, accountability, and long-term asset stewardship.

The company should feel:

- Dependable
- Calm under pressure
- Intelligent
- Practical
- Responsive
- Modern
- Trustworthy
- Fair but firm

The brand should never feel:

- Corporate
- Aggressive
- Gimmicky
- Salesy
- Emotional
- Sarcastic
- Combative
- Flashy

## Target Audiences

### Rental Property Owners

Goals:

- Maximize income
- Reduce stress
- Protect assets
- Avoid operational problems

Messaging style:

- Confidence
- Systems
- Transparency
- Operational excellence

### Real Estate Investors

Goals:

- ROI
- Scaling portfolios
- Efficient operations
- Long-term value creation

Messaging style:

- Data-driven
- Strategic
- Operationally sophisticated
- Practical

### Condo and HOA Boards

Goals:

- Stability
- Professionalism
- Homeowner satisfaction
- Budget control

Messaging style:

- Organized
- Diplomatic
- Responsive
- Governance-focused

### Residents and Tenants

Goals:

- Safe housing
- Responsiveness
- Clarity
- Respect

Messaging style:

- Empathetic
- Clear
- Direct
- Helpful

Never demean or mock residents.

## Core Brand Values

- Clear communication
- Accountability
- Professionalism
- Operational excellence
- Respect for residents and homeowners
- Long-term thinking
- Calm problem solving
- Practical systems
- Fairness
- Responsiveness

## Voice and Writing Style

Voice characteristics:

- Professional
- Calm
- Confident
- Concise
- Thoughtful
- Helpful
- Intelligent
- Solution-oriented

Writing style:

- Use plain English
- Use short paragraphs
- Avoid hype
- Avoid excessive emojis
- Avoid slang
- Avoid trendy internet language
- Avoid all caps
- Use confident but modest language

Good tone examples:

- "Clear communication prevents small problems from becoming expensive ones."
- "Good property management protects both residents and property owners."
- "Preventative maintenance saves time, money, and stress."
- "Professional systems create better resident experiences."

Bad tone examples:

- "Crushing the rental game!"
- "Tenants are a nightmare."
- "Get rich with rentals!"
- "Landlords hate this trick!"

## Approved Content Categories

- Property management education
- Preventative maintenance
- Rental owner tips
- Investor operations
- Condo/HOA governance
- Resident reminders
- Seasonal property care
- Local New Hampshire / Southern Maine community content
- Property showcases
- Company operations

## Audience List

- Rental property owners
- Real estate investors
- Condo boards
- HOA boards
- Residents
- Homeowners
- Vendors
- Local community

## Platform Rules

### Facebook

- Community-focused
- Educational
- Medium length
- Good for local content, property updates, education, and community engagement

### Instagram

- Concise
- Visual-first
- Include an image prompt
- Maximum 3 approved emojis
- Good for carousel posts, before and after content, property visuals, and seasonal reminders

### LinkedIn

- Professional
- Strategic
- Operations-focused
- No emojis unless very appropriate
- Good for systems, leadership, operations, investor insights, and property management best practices

## Hashtag Rules

Use 3 to 8 hashtags from this list:

- #ArthurThomasProperties
- #PropertyManagement
- #NHRealEstate
- #NewHampshireRealEstate
- #MaineRealEstate
- #RentalProperty
- #RealEstateInvestor
- #CondoManagement
- #HOAManagement
- #PreventativeMaintenance
- #PropertyCare
- #ResidentExperience

## Safety Rules

The app must block or flag:

- Fair housing risk language
- Political content
- Confidential resident or property owner information
- Legal threats
- Eviction commentary
- Resident shaming
- Fabricated property details
- Unapproved pricing
- Claims of guaranteed returns
- Profanity
- Discriminatory language

## Fair Housing Compliance Rules

Avoid language implying:

- Preferred race
- Preferred age
- Preferred gender
- Family status preference
- Disability preference
- Religion preference
- "Perfect for young professionals"
- "Ideal bachelor pad"
- "Safe neighborhood"
- "Christian community"

Use neutral housing language only.

## Visual Style Rules

Preferred visuals:

- Clean architecture
- Natural lighting
- Authentic photography
- New England seasonal imagery
- Maintenance in action
- Real operational work
- Subtle branding

Avoid:

- Stock-photo looking people
- Overly staged luxury imagery
- Fake smiling teams
- Meme graphics
- Flashy effects
- Excessive filters

## CTA Rules

Use soft CTAs only.

Good:

- "Reach out with questions."
- "Contact us to learn more."
- "We're happy to help."
- "Looking for professional management support?"

Avoid:

- Hard selling
- Fake urgency
- Manipulative language

## Posting Rules

Recommended frequency: 3 to 5 posts per week.

Suggested mix:

- 40% educational
- 25% property showcase
- 20% local and community
- 15% company culture and operations

Scheduling suggestions:

- Monday: investor or operations insight
- Wednesday: maintenance or property tip
- Friday: listing, community, or property showcase
- Monthly: HOA or board education
- Seasonally: winter prep, snow removal, heating reminders, spring maintenance, fall inspections

## Example Posts

Investor education:

"Preventative maintenance is one of the simplest ways to reduce long-term ownership costs. Small issues caught early are almost always less expensive than emergency repairs later."

Resident communication:

"Cold weather reminder: Please keep interior temperatures above 55 degrees during winter months to help prevent freeze-related damage."

HOA and condo:

"Strong condo associations are built on consistent communication, proactive planning, and clear financial stewardship."

Property showcase:

"Recently completed exterior improvements on this New Hampshire property. Small upgrades to curb appeal can make a significant long-term difference in both resident experience and property value."

## AI Safety Rules

The AI agent:

- Must not fabricate property details
- Must not invent pricing
- Must not post confidential information
- Must not post resident names
- Must not discuss active disputes
- Must not discuss evictions publicly
- Must not publish without approval
- Must flag potentially sensitive content for human review

## Human Review Rule

All posts require approval before publishing.

The AI may:

- Draft
- Suggest
- Schedule

The AI may not:

- Autonomously publish
- Reply emotionally
- Argue with commenters
- Make legal statements
